const test = require('node:test');
const assert = require('node:assert/strict');
const Calc = require('../public/calc.js');

test('расчёт по цене за м²: 1000×500 мм, 400 ₽/м², отходы 10%, работа 300, доп. 50, прибыль 30%', () => {
  const r = Calc.calcUnit({ lengthMm: 1000, widthMm: 500, priceMode: 'm2', pricePerM2: 400, wastePct: 10, labor: 300, extra: 50, profitPct: 30 });
  assert.equal(r.areaM2, 0.5);
  assert.equal(r.materialNet, 200);
  assert.equal(r.materialWaste, 20);
  assert.equal(r.materialTotal, 220);
  assert.equal(r.cost, 570);
  assert.equal(r.price, 741);
  assert.equal(r.profit, 171);
});

test('расчёт по цене листа: лист 2500×1250 за 5000 ₽ = 1600 ₽/м²', () => {
  const r = Calc.calcUnit({ lengthMm: 1000, widthMm: 1000, priceMode: 'sheet', sheetPrice: 5000, sheetLengthMm: 2500, sheetWidthMm: 1250, wastePct: 0, profitPct: 0 });
  assert.equal(r.pricePerM2, 1600);
  assert.equal(r.cost, 1600);
  assert.equal(r.price, 1600);
});

test('запятая как десятичный разделитель и пустые необязательные поля', () => {
  const r = Calc.calcUnit({ lengthMm: '1000', widthMm: '500', priceMode: 'm2', pricePerM2: '400,50', wastePct: '', labor: '', extra: '', profitPct: '' });
  assert.equal(r.materialNet, 200.25);
  assert.equal(r.price, 200.25);
});

test('ошибки валидации', () => {
  const base = { lengthMm: 1000, widthMm: 500, priceMode: 'm2', pricePerM2: 400 };
  assert.throws(() => Calc.calcUnit({ ...base, lengthMm: 0 }), /Длина/);
  assert.throws(() => Calc.calcUnit({ ...base, widthMm: -5 }), /Ширина/);
  assert.throws(() => Calc.calcUnit({ ...base, pricePerM2: '' }), /Цена металла/);
  assert.throws(() => Calc.calcUnit({ ...base, pricePerM2: 'abc' }), /числом/);
  assert.throws(() => Calc.calcUnit({ ...base, wastePct: -1 }), /Отходы/);
  assert.throws(() => Calc.calcUnit({ ...base, labor: -10 }), /работы/);
  assert.throws(() => Calc.calcUnit({ ...base, priceMode: 'sheet', sheetPrice: 100, sheetLengthMm: 0, sheetWidthMm: 1000 }), /Длина листа/);
});

test('итоги заказа', () => {
  const o = Calc.calcOrder({ qty: 4, unitCost: 2150, unitPrice: 3100 });
  assert.equal(o.revenue, 12400);
  assert.equal(o.totalCost, 8600);
  assert.equal(o.profit, 3800);
  assert.equal(o.marginPct, 30.65);
});

test('округление копеек без накопления ошибки', () => {
  const o = Calc.calcOrder({ qty: 3, unitCost: 0.1, unitPrice: 0.2 });
  assert.equal(o.revenue, 0.6);
  assert.equal(o.profit, 0.3);
});

test('ошибки заказа: нулевое и дробное количество', () => {
  assert.throws(() => Calc.calcOrder({ qty: 0, unitCost: 1, unitPrice: 1 }), /Количество/);
  assert.throws(() => Calc.calcOrder({ qty: 1.5, unitCost: 1, unitPrice: 1 }), /целым/);
  assert.throws(() => Calc.calcOrder({ qty: 1, unitCost: -1, unitPrice: 1 }), /Себестоимость/);
});
