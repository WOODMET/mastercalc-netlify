const test = require('node:test');
const assert = require('node:assert/strict');
const { createApi } = require('../netlify/functions/lib/core.cjs');

function setup(envExtra, fetchImpl) {
  const m = new Map();
  const store = { get: async (k) => (m.has(k) ? JSON.parse(m.get(k)) : null), set: async (k, v) => { m.set(k, JSON.stringify(v)); } };
  const env = { SESSION_SECRET: 'x'.repeat(40), APP_URL: 'https://shop.example', ...envExtra };
  const handle = createApi({ store, env, fetchImpl });
  let cookie = '';
  const call = async (method, path, body, { raw } = {}) => {
    if (path === '/auth/register' && body && !('consent' in body)) body = { ...body, consent: true };
    const headers = { 'content-type': 'application/json', origin: 'https://shop.example' };
    if (cookie) headers.cookie = cookie;
    const res = await handle(new Request('https://shop.example/api' + path, { method, headers, body: body ? JSON.stringify(body) : undefined }));
    const sc = res.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    if (raw) return res;
    return { status: res.status, data: await res.json() };
  };
  return { call, store, setCookie: (c) => { cookie = c; } };
}
const order = (o) => ({ client: 'Клиент', product: 'Козырёк', size: '1×1', qty: 2, unitCost: 100, unitPrice: 150, ...o });

test('без SESSION_SECRET сервер отказывает', async () => {
  const handle = createApi({ store: {}, env: {} });
  const res = await handle(new Request('https://a.b/api/me'));
  assert.equal(res.status, 500);
});

test('регистрация, вход, выход, /me', async () => {
  const { call } = setup();
  assert.equal((await call('GET', '/me')).status, 401);
  assert.equal((await call('POST', '/auth/register', { email: 'bad', password: '12345678' })).status, 400);
  assert.equal((await call('POST', '/auth/register', { email: 'a@b.ru', password: 'short' })).status, 400);
  const r = await call('POST', '/auth/register', { email: 'A@b.ru', password: 'password1' });
  assert.equal(r.status, 201);
  assert.equal(r.data.user.plan, 'free');
  assert.equal((await call('GET', '/me')).data.user.email, 'a@b.ru');
  assert.equal((await call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' })).status, 409);
  await call('POST', '/auth/logout');
  const { call: c2 } = setup();
  assert.equal((await c2('POST', '/auth/login', { email: 'x@y.ru', password: 'password1' })).status, 401);
});

test('неверный пароль и подделанная сессия', async () => {
  const t = setup();
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  assert.equal((await t.call('POST', '/auth/login', { email: 'a@b.ru', password: 'wrongpass1' })).status, 401);
  assert.equal((await t.call('POST', '/auth/login', { email: 'a@b.ru', password: 'password1' })).status, 200);
  t.setCookie('mk_session=abc.def');
  assert.equal((await t.call('GET', '/me')).status, 401);
});

test('заказы: CRUD, лимит FREE, чужие заказы недоступны', async () => {
  const t = setup();
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  const c = await t.call('POST', '/orders', order());
  assert.equal(c.status, 201);
  assert.equal(c.data.order.revenue, 300);
  assert.equal(c.data.order.profit, 100);
  assert.equal((await t.call('POST', '/orders', order({ qty: 0 }))).status, 400);
  assert.equal((await t.call('POST', '/orders', order({ status: 'x' }))).status, 400);
  assert.equal((await t.call('POST', '/orders', order({ unitPrice: -1 }))).status, 400);
  const u = await t.call('PUT', '/orders/' + c.data.order.id, order({ qty: 3, status: 'work' }));
  assert.equal(u.data.order.revenue, 450);
  for (let i = 0; i < 4; i++) assert.equal((await t.call('POST', '/orders', order())).status, 201);
  const lim = await t.call('POST', '/orders', order());
  assert.equal(lim.status, 402); assert.equal(lim.data.code, 'LIMIT');
  assert.equal((await t.call('DELETE', '/orders/' + c.data.order.id)).status, 200);
  assert.equal((await t.call('DELETE', '/orders/999')).status, 404);
  assert.equal((await t.call('GET', '/orders')).data.orders.length, 4);
  // другой пользователь не видит чужое
  const t2 = setup(); // отдельное хранилище — проверим изоляцию в одном хранилище ниже
  await t2.call('POST', '/auth/register', { email: 'z@z.ru', password: 'password1' });
  assert.equal((await t2.call('GET', '/orders')).data.orders.length, 0);
});

test('демо-данные, CSV только для PRO', async () => {
  const t = setup();
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  assert.equal((await t.call('POST', '/demo')).status, 201);
  assert.equal((await t.call('POST', '/demo')).status, 409);
  assert.equal((await t.call('GET', '/orders')).data.orders.length, 4);
  assert.equal((await t.call('GET', '/orders.csv', null, { raw: true })).status, 402);
});

test('настройки бренда', async () => {
  const t = setup();
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  assert.equal((await t.call('PUT', '/settings', { brand: '', kpValidDays: 7 })).status, 400);
  assert.equal((await t.call('PUT', '/settings', { brand: 'MY', kpValidDays: 0 })).status, 400);
  assert.equal((await t.call('PUT', '/settings', { brand: 'MY', kpValidDays: 10 })).status, 200);
  assert.equal((await t.call('GET', '/me')).data.user.settings.brand, 'MY');
});

test('CSRF: чужой Origin отклоняется', async () => {
  const t = setup();
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  const res = await createApi({ store: t.store, env: { SESSION_SECRET: 'x'.repeat(40) } })(
    new Request('https://shop.example/api/orders', { method: 'POST', headers: { origin: 'https://evil.example', 'content-type': 'application/json' }, body: '{}' }));
  assert.equal(res.status, 403);
});

test('оплата не подключена → понятная ошибка, PRO не выдаётся', async () => {
  const t = setup();
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  assert.equal((await t.call('GET', '/plans')).data.paymentsConfigured, false);
  assert.equal((await t.call('POST', '/billing/checkout', { plan: 'pro_month' })).status, 503);
  assert.equal((await t.call('POST', '/billing/checkout', { plan: 'nope' })).status, 400);
});

test('оплата ЮKassa: сумма берётся из тарифа, PRO выдаётся только после подтверждения через API, без двойного продления', async () => {
  const calls = [];
  let remote = { id: 'pay-1234567890', status: 'pending', paid: false, amount: { value: '990.00', currency: 'RUB' }, metadata: {} };
  const fetchImpl = async (url, opts = {}) => {
    calls.push({ url, opts });
    if (opts.method === 'POST') {
      const b = JSON.parse(opts.body);
      remote.metadata = b.metadata;
      return new Response(JSON.stringify({ id: remote.id, confirmation: { confirmation_url: 'https://yookassa.example/pay' } }), { status: 200 });
    }
    return new Response(JSON.stringify(remote), { status: 200 });
  };
  const t = setup({ YOOKASSA_SHOP_ID: '1', YOOKASSA_SECRET_KEY: 'k' }, fetchImpl);
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  const co = await t.call('POST', '/billing/checkout', { plan: 'pro_month', amount: '1.00' });
  assert.equal(co.data.url, 'https://yookassa.example/pay');
  const sent = JSON.parse(calls[0].opts.body);
  assert.equal(sent.amount.value, '990.00'); // сумму от клиента не берём
  assert.equal((await t.call('POST', '/billing/sync')).data.user.plan, 'free'); // ещё не оплачено
  // подделанный вебхук без реальной оплаты ничего не даёт
  await t.call('POST', '/billing/webhook', { object: { id: remote.id } });
  assert.equal((await t.call('GET', '/me')).data.user.plan, 'free');
  // платёж реально прошёл
  remote.status = 'succeeded'; remote.paid = true;
  const s1 = await t.call('POST', '/billing/sync');
  assert.equal(s1.data.user.plan, 'pro');
  const until1 = s1.data.user.planUntil;
  await t.call('POST', '/billing/webhook', { object: { id: remote.id } });
  const s2 = await t.call('POST', '/billing/sync');
  assert.equal(s2.data.user.planUntil, until1); // не продлили второй раз
  assert.ok(new Date(until1) - Date.now() > 29 * 86400000);
  assert.equal((await t.call('POST', '/orders', order())).status, 201);
  assert.equal((await t.call('GET', '/orders.csv', null, { raw: true })).status, 200);
});

test('платёж с неверной суммой не активирует PRO', async () => {
  let remote;
  const fetchImpl = async (url, opts = {}) => {
    if (opts.method === 'POST') { remote = { id: 'pay-abcdefghij', status: 'succeeded', paid: true, amount: { value: '1.00', currency: 'RUB' }, metadata: JSON.parse(opts.body).metadata };
      return new Response(JSON.stringify({ id: remote.id, confirmation: { confirmation_url: 'u' } }), { status: 200 }); }
    return new Response(JSON.stringify(remote), { status: 200 });
  };
  const t = setup({ YOOKASSA_SHOP_ID: '1', YOOKASSA_SECRET_KEY: 'k' }, fetchImpl);
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  await t.call('POST', '/billing/checkout', { plan: 'pro_month' });
  assert.equal((await t.call('POST', '/billing/sync')).data.user.plan, 'free');
});

test('регистрация без согласия с офертой отклоняется', async () => {
  const t = setup();
  const r = await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1', consent: false });
  assert.equal(r.status, 400);
  assert.match(r.data.error, /оферт/);
});

test('восстановление пароля: письмо, одноразовая ссылка, старые сессии сбрасываются', async () => {
  const mails = [];
  const fetchImpl = async (url, opts) => { mails.push({ url, body: JSON.parse(opts.body) }); return new Response('{}', { status: 200 }); };
  const env = { RESEND_API_KEY: 're_x', MAIL_FROM: 'MK <no-reply@shop.example>' };
  const t = setup(env, fetchImpl);
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  const oldCookie = (await t.call('GET', '/me')).status === 200 && 'ok';
  assert.ok(oldCookie);
  // неизвестный адрес: тот же ответ, письмо не уходит
  assert.equal((await t.call('POST', '/auth/forgot', { email: 'nobody@b.ru' })).status, 200);
  assert.equal(mails.length, 0);
  assert.equal((await t.call('POST', '/auth/forgot', { email: 'bad' })).status, 400);
  assert.equal((await t.call('POST', '/auth/forgot', { email: 'a@b.ru' })).status, 200);
  assert.equal(mails.length, 1);
  assert.equal(mails[0].url, 'https://api.resend.com/emails');
  assert.deepEqual(mails[0].body.to, ['a@b.ru']);
  const token = mails[0].body.text.match(/#reset=([\w-]+)/)[1];
  // старая сессия (куки до сброса)
  const { cookieBefore } = { cookieBefore: null };
  assert.equal((await t.call('POST', '/auth/reset', { token: 'wrong', password: 'newpassword1' })).status, 400);
  assert.equal((await t.call('POST', '/auth/reset', { token, password: 'short' })).status, 400);
  const r = await t.call('POST', '/auth/reset', { token, password: 'newpassword1' });
  assert.equal(r.status, 200);
  assert.equal((await t.call('GET', '/me')).status, 200); // новая сессия выдана
  assert.equal((await t.call('POST', '/auth/reset', { token, password: 'another12345' })).status, 400); // повторно нельзя
  await t.call('POST', '/auth/logout');
  assert.equal((await t.call('POST', '/auth/login', { email: 'a@b.ru', password: 'password1' })).status, 401);
  assert.equal((await t.call('POST', '/auth/login', { email: 'a@b.ru', password: 'newpassword1' })).status, 200);
});

test('после смены пароля старая сессия недействительна', async () => {
  const mails = [];
  const fetchImpl = async (u, o) => { mails.push(JSON.parse(o.body)); return new Response('{}', { status: 200 }); };
  const t = setup({ RESEND_API_KEY: 'k', MAIL_FROM: 'a@b.c' }, fetchImpl);
  await t.call('POST', '/auth/register', { email: 'a@b.ru', password: 'password1' });
  let old;
  { const res = await t.call('POST', '/auth/login', { email: 'a@b.ru', password: 'password1' }); old = res.status; }
  const t2 = { call: t.call };
  // сохраняем куку до сброса
  const before = (await (async () => { let c; const orig = t.setCookie; return null; })());
  await t.call('POST', '/auth/forgot', { email: 'a@b.ru' });
  const token = mails[0].text.match(/#reset=([\w-]+)/)[1];
  const raw = await t.call('GET', '/me', null, { raw: true });
  assert.equal(raw.status, 200);
  // кука до сброса сохранена в замыкании call → воспроизводим вручную
  const cookieOld = (await t.call('POST', '/auth/login', { email: 'a@b.ru', password: 'password1' }, { raw: true })).headers.get('set-cookie').split(';')[0];
  await t.call('POST', '/auth/reset', { token, password: 'newpassword1' });
  t.setCookie(cookieOld);
  assert.equal((await t.call('GET', '/me')).status, 401);
});

test('восстановление не настроено → 503', async () => {
  const t = setup();
  assert.equal((await t.call('POST', '/auth/forgot', { email: 'a@b.ru' })).status, 503);
});
